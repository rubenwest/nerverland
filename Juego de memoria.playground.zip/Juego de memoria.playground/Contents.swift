// Juego de memoria

/*
 
 Generar un rango de 0 a 100, incluye el número 100 en el rango.
 Tienes que iterar el rango completo, utilizando la sentencia for para obtener cada número del rango y aplicar las siguientes reglas de impresión.
 Al evaluar cada número debes aplicar las siguientes reglas:
 - Si el número es divisible entre 5, imprime: # el número  + “Bingo!!!”
 
 - Si el número es par, imprime: # el número + “par!!!”
 
 - Si el número es impar, imprime: # el número + “impar!!!”
 
 - Si el número se encuentra dentro de un rango del 30 al 40, imprime: # el número +  “Viva Swift!!!”
 
 Debes de usar la interpolación de variables para realizar la impresión de cada número.
 
 */

import UIKit


//Recorremos la variable i desde 1 hasta 100 inclusive

for i in 1...100 {

    //Seleccionamos las distintas casuisticas
    switch i {
    //Seleccionamos los casos en que la variable i esté dentro del rango [30,40]
    case 30...40:
        
        print("#\(i) Viva Swift!!!")
        
    //Por defecto verificamos el resto de casos
    default:
        //Comprobamos si el numero es par
        if i%2 == 0 {
            
            print("#\(i) par!!!")
            
        } //Si no es par verificamos que sea 5 
            
            else if i%5 == 0 {
        
            print("#\(i) Bingo!!!")
        
        } //En el caso de que no sea par o 5 
            
            else {
        
            print("#\(i) impar!!!")
        
        }
            }
}


//Fin del programa
